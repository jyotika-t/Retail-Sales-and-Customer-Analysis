# Power BI Dashboard Setup Guide
# Retail Sales & Customer Analytics
# ============================================================

## STEP 1 — CONNECT DATA TO POWER BI

### Option A: From CSV (Easiest)
1. Open Power BI Desktop
2. Home → Get Data → Text/CSV
3. Browse to: `retail_analytics_project/data/cleaned_data.csv`
4. Click Load

Also load the RFM file:
- Get Data → Text/CSV → `retail_analytics_project/data/rfm_segments.csv`

### Option B: From MySQL Database
1. Home → Get Data → MySQL Database
2. Server: localhost, Database: retail_analytics
3. Select tables/views and click Load

---

## STEP 2 — DATA MODEL SETUP

In the Model view:
- cleaned_data and rfm_segments are joined on `Customer ID`
- No additional relationships needed for single-table analysis

---

## STEP 3 — CREATE DATE TABLE (Important!)

In Power Query Editor → New Query → Blank Query:
Paste this M code:

```
let
    StartDate = #date(2014, 1, 1),
    EndDate   = #date(2018, 12, 31),
    Duration  = Duration.Days(EndDate - StartDate) + 1,
    Dates     = List.Dates(StartDate, Duration, #duration(1, 0, 0, 0)),
    Table     = Table.FromList(Dates, Splitter.SplitByNothing(), {"Date"}),
    TypedDate = Table.TransformColumnTypes(Table, {{"Date", type date}}),
    Year      = Table.AddColumn(TypedDate, "Year",    each Date.Year([Date]),    Int64.Type),
    Month     = Table.AddColumn(Year,      "Month",   each Date.Month([Date]),   Int64.Type),
    MonthName = Table.AddColumn(Month,     "MonthName", each Date.ToText([Date], "MMM"), type text),
    Quarter   = Table.AddColumn(MonthName, "Quarter", each "Q" & Text.From(Date.QuarterOfYear([Date])), type text),
    WeekDay   = Table.AddColumn(Quarter,   "Weekday", each Date.ToText([Date], "ddd"), type text)
in
    WeekDay
```

Name this query: `DateTable`

Then in Model view: connect DateTable[Date] → cleaned_data[Order Date]
Mark DateTable as "Mark as Date Table"

---

## STEP 4 — DAX MEASURES

Create a dedicated Measures table:
1. Home → Enter Data → Name it "Measures" → Load
2. Right-click "Measures" table → New Measure for each below

```dax
-- ── CORE KPIs ──────────────────────────────────────────────

Total Revenue = SUM(cleaned_data[Sales])

Total Orders = DISTINCTCOUNT(cleaned_data[Order ID])

Total Customers = DISTINCTCOUNT(cleaned_data[Customer ID])

Total Products = DISTINCTCOUNT(cleaned_data[Product ID])

Avg Order Value =
DIVIDE(
    SUMX(
        VALUES(cleaned_data[Order ID]),
        CALCULATE(SUM(cleaned_data[Sales]))
    ),
    DISTINCTCOUNT(cleaned_data[Order ID])
)


-- ── TIME INTELLIGENCE ──────────────────────────────────────

Revenue YTD =
TOTALYTD([Total Revenue], DateTable[Date])

Revenue MTD =
TOTALMTD([Total Revenue], DateTable[Date])

Revenue QTD =
TOTALQTD([Total Revenue], DateTable[Date])

Revenue Previous Year =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(DateTable[Date]))

YoY Revenue Growth % =
DIVIDE(
    [Total Revenue] - [Revenue Previous Year],
    [Revenue Previous Year],
    0
) * 100

YoY Growth Label =
VAR growth = [YoY Revenue Growth %]
RETURN
IF(growth >= 0,
    "▲ " & FORMAT(growth, "0.0") & "%",
    "▼ " & FORMAT(ABS(growth), "0.0") & "%"
)

Revenue Previous Month =
CALCULATE([Total Revenue], PREVIOUSMONTH(DateTable[Date]))

MoM Revenue Growth % =
DIVIDE(
    [Total Revenue] - [Revenue Previous Month],
    [Revenue Previous Month],
    0
) * 100


-- ── CUSTOMER ANALYTICS ─────────────────────────────────────

Repeat Customers =
CALCULATE(
    DISTINCTCOUNT(cleaned_data[Customer ID]),
    FILTER(
        VALUES(cleaned_data[Customer ID]),
        CALCULATE(DISTINCTCOUNT(cleaned_data[Order ID])) > 1
    )
)

New Customers =
CALCULATE(
    DISTINCTCOUNT(cleaned_data[Customer ID]),
    FILTER(
        VALUES(cleaned_data[Customer ID]),
        CALCULATE(DISTINCTCOUNT(cleaned_data[Order ID])) = 1
    )
)

Customer Retention Rate % =
DIVIDE([Repeat Customers], [Total Customers], 0) * 100

Avg Revenue Per Customer =
DIVIDE([Total Revenue], [Total Customers], 0)


-- ── REGIONAL ───────────────────────────────────────────────

West Revenue =
CALCULATE([Total Revenue], cleaned_data[Region] = "West")

East Revenue =
CALCULATE([Total Revenue], cleaned_data[Region] = "East")

Central Revenue =
CALCULATE([Total Revenue], cleaned_data[Region] = "Central")

South Revenue =
CALCULATE([Total Revenue], cleaned_data[Region] = "South")


-- ── PRODUCT / CATEGORY ─────────────────────────────────────

Technology Revenue =
CALCULATE([Total Revenue], cleaned_data[Category] = "Technology")

Furniture Revenue =
CALCULATE([Total Revenue], cleaned_data[Category] = "Furniture")

Office Supplies Revenue =
CALCULATE([Total Revenue], cleaned_data[Category] = "Office Supplies")

Revenue Rank (Product) =
RANKX(ALL(cleaned_data[Product Name]), [Total Revenue], , DESC)

Revenue % of Total =
DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALL(cleaned_data)), 0)


-- ── SHIPPING ───────────────────────────────────────────────

Avg Ship Days =
AVERAGEX(
    cleaned_data,
    DATEDIFF(cleaned_data[Order Date], cleaned_data[Ship Date], DAY)
)
```

---

## STEP 5 — BUILD THE DASHBOARD (4 Pages)

### PAGE 1 — Executive Summary
Layout:
- Top row: 5 KPI cards
  - [Total Revenue]  [Total Orders]  [Total Customers]  [Avg Order Value]  [YoY Growth Label]
- Row 2 left: Line chart — Monthly Revenue Trend (X=DateTable[Month], Y=[Total Revenue])
- Row 2 right: Donut chart — Sales by Category
- Row 3 left: Bar chart — Revenue by Region (horizontal)
- Row 3 right: Table — Top 10 Products

### PAGE 2 — Sales Deep Dive
- Area chart: Monthly Revenue by Category (stacked)
- Bar chart: Revenue by Sub-Category (sorted desc)
- Matrix: Year (rows) × Quarter (cols) → [Total Revenue] (conditional formatting)
- Slicer: Year | Region | Category
- Line + Bar: YoY Growth dual axis

### PAGE 3 — Customer Analytics
- KPI cards: [Total Customers]  [Repeat Customers]  [Customer Retention Rate %]  [Avg Revenue Per Customer]
- Pie/Donut: Revenue by Segment
- Bar chart: Revenue by Segment (Consumer / Corporate / Home Office)
- Table: Top 20 Customers (name, segment, revenue, orders, last order)
- Scatter plot: Orders vs Total Spend (bubble = avg order value)
- If rfm_segments is loaded: Bar chart — Customers by RFM Segment

### PAGE 4 — Regional Performance
- Filled Map: Revenue by State (or City)
- Bar chart: Top 15 Cities
- Matrix: Region (row) × Category (col) → Revenue with color scale
- Bar chart: Avg Ship Days by Region + Ship Mode
- Slicer: Region | State | Year

---

## STEP 6 — SLICERS (add to every page)
- Year slicer (from DateTable)
- Region slicer (dropdown)
- Category slicer (list)
- Segment slicer (list)

Add "Sync Slicers" (View → Sync Slicers) so they work across pages.

---

## STEP 7 — CONDITIONAL FORMATTING
1. Revenue KPI card → add color rule: green if YoY Growth > 0, red otherwise
2. Matrix visuals → background color scale (white → dark blue for high revenue)
3. Top Products table → Revenue column bar visualization

---

## STEP 8 — PUBLISH (Optional)
- File → Publish → Publish to Power BI Service
- Share the dashboard link with recruiters/interviewers

---

## THEME SUGGESTION
- Use the "Slate" built-in theme OR import custom theme
- Primary color: #2C3E50 (dark navy)
- Accent: #3498DB (blue), #E74C3C (red), #2ECC71 (green)
- Font: Segoe UI 12pt body, 16pt headers
